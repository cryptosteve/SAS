<?php
require_once('inc/radius.class.php');
require_once('inc/radius.data.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
    <head>
        <title>
           SafeNet Authentication Service DEMO
        </title>
		<link href="http://fonts.googleapis.com/css?family=Abel" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" type="text/css" href="style.css" />
    </head>
    <body>
		<img src="img/logo.png">
        <?php
        if ((isset($_POST['user'])) && ('' != trim($_POST['user'])) &&(isset($_POST['pass'])) && ('' != trim($_POST['pass'])))
        {
			
            $radius = new Radius($SAS_IP,$SAS_Secret);
			//$radius->SetNasPort($SAS_Port);
            if ($SAS_Debug){$radius->SetDebugMode(TRUE);}

            if ($radius->AccessRequest($_POST['user'], $_POST['pass']))
            {?>
				<br /><img src="img/accept.png"/><br />
                <strong>Authentication accepted.</strong>
				<?php
            }
            else
            {?>
				<br /><img src="img/deny.png"/><br />
                <strong>Authentication rejected.</strong>
				<?php
            }
            echo "<br />";
            echo "<br />";
            echo "<a href=\"".$_SERVER['PHP_SELF']."\">Reload authentication form</a>";
			echo "<br />";
			//echo "<br /><strong>GetReadableReceivedAttributes</strong><br />";
            //echo $radius->GetReadableReceivedAttributes();
        }
        else
        {
		?>
            <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
				<table border="0"><tr><td width="100px"><img src="img/access.png"/><br /></td><td>
				<?php if ((isset($_POST['user'])) && ('' != trim($_POST['user'])))
					{
				?>
					<!-- User is entered - generate GRIDSURE -->
					User: <input name="user" type="text" value="<?php echo $_POST['user']; ?>" />
					<br />
					<img src="<?php echo $SAS_GridImageUrl; ?>/SignIn.aspx?getChallengeImage=true&userName=<?php echo $_POST['user']; ?>"/> <br/>
					Pass: <input name="pass" type="text" value="" /> (text type for educational purpose only)
					<input name="submit" type="submit" value="Check authentication" />
				<?php }else{ ?>
					<!-- User is not entered, generate default form -->
					User: <input name="user" type="text" value="" /> <input name="submit" type="submit" value="Generate GrIDsure" /><br />
					Pass: <input name="pass" type="text" value="" /> (enter Password if not using GrIDsure token)<br /> <!-- type="text" for educational purpose only ! -->
					<input name="submit" type="submit" value="Check authentication" />
				<?php }?>
				</td></tr></table>
            </form>
            <?php }?>
		<div style="height: 20px; display: inline; text-align: left;">
			<span id="copyright_CopyrightLabel" style="color:#000000;font-size:x-small">Copyright � 2012. SafeNet Inc. All Rights Reserved.</span>
		</div>
    </body>
<html>
