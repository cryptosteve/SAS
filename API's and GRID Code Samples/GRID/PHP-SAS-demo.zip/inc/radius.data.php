<?php
$SAS_IP='209.217.70.2';
$SAS_Port='1812';
$SAS_Secret='secret';
$SAS_Debug=False;
$SAS_GridImageUrl='http://spedemo.cryptocard.com/blackshieldss/O/I702C3S6HH';
?>