
{
	//URL of the BlackShield ID Self Service page
	var gridMakerURL = "https://your.selfServiceURL.com/blackshieldss/index.aspx?getChallengeImage=true&userName=";

	var usernameName = "username";
	var passwordName = "password";

	document.write("<input type='button' id='gridButton' value='Get GrID' disabled='disabled' onclick=getGrID() class='submitbutton'>");
	document.write("<img id='gridplaceholder' style='visibility:hidden;position: absolute; left:100;top:350;'>");

	function getGrID() 
	{
		var userControl = document.getElementsByName(usernameName)[0];
		var name = userControl.value;

		if (name=="") 
		{
			alert ("User name required.");
			userControl.focus()
		}
		else
		{
			var gridControl = document.getElementById("gridplaceholder");
			gridControl.src = gridMakerURL + name;
			gridControl.style.visibility = "visible";

			document.getElementsByName(passwordName)[0].focus()
		}		
	}

	function enableButton() {
	    if (document.getElementsByName(usernameName)[0].value == "") {
		document.getElementById("gridButton").disabled = true;
	    } else {
		document.getElementById("gridButton").disabled = false;
	    }
	}
}


