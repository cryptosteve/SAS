Prerequisites

- The Juniper SSL VPN device must support uploading custom login pages (Juniper SSL VPN model SA 2500 or higher).
- The BlackShield Self Service Site must be publicly accessible to SSL VPN clients.
- The Juniper device must already be configured to perform RADIUS authentication against the BlackShield server.


A. Adding the BlackShield Self Service URL to the gridsure.js file

1. Open gridsure.js with a text editor.
2. Change the value of gridMakerURL to reflect the location of your BlackShield Self Service website then save the file

ex. 
var gridMakerURL = "https://www.mycompany.com/blackshieldss/index.aspx?getChallengeImage=true&userName=";


B. Adding the CRYPTOCard GrIDsure enabled Sign-in page.

1. Login as an administrator to the Juniper device.
2. Select Authentication, Signing In, Sign-In Pages.
3. Select the "Upload Custom Pages" button.
4. In the "Sample Templates Files" section select "Sample".  Download sample.zip to a temporary folder.
5. Rename the sample.zip file to cryptocard.zip. 
6. Add the gridsure.js and LoginPage.thtml file to cryptocard.zip (if prompted, overwrite the existing LoginPage.thtml file).
7. In "Upload Custom Sign-In Pages", enter "CRYPTOCard GrID Enabled" into the Name field and in "Page Type" select "Access". In "Templates File" browse to the cryptocard.zip file then select the "Upload Custom Pages" button.

C. Assigning the CRYPTOCard GrIDsure enabled Sign-in page to a Sign-in Policy.

1. Login as an administrator to the Juniper device.
2. Select Authentication, Signing In, Sign-In Policies.
3. Select the CRYPTOCard authentication enabled "User URL".
4. In the Sign-in page section, select "CRYPTOCard GrID Enabled" then save the settings.


D. Login as a CRYPTOCard GrIDsure enabled user.

1. Open a web browser and browse to the CRYPTOCard enabled Juniper SSL VPN sign-in page.
2. Enter the username then select the "Get Grid" button, a grid will appear in the screen.
3. Enter the PIP into the password field then select Sign-in.


Optional - Enabled Challenge-response requests

1. Login as an administrator to the Juniper device.
2. Select Authentication, Auth. Servers.
3. Select the CRYPTOCard RADIUS enabled authentication server.
4. In "Custom Radius Rules" select "New Radius Rule...".
5. In "Display Name" enter "Display challenges", set "Response Packet Type" to "Access Challenge".  In "Attribute criteria" set "Radius Attribute" to "Reply-Message(18) with a "Value" of "*".  In "Then take action..." select "show Generic Login page".
6. Save the changes.

 

