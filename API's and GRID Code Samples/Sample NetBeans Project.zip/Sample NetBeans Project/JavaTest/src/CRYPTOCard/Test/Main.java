/*
/*
 * CRYPTOCard Java API Sample Project
 * Before running this project, add BSIDJavaAPI.jar to your project
 * BSIDJavaAPI use libJCryptoWrapper.so on Linux and JCryptoWrapperWin.dll
 * on Windows to communicate with BSID. Management is via JCryptoWrapperWin.ini on Windows and
 * JCryptoWrapper.ini on Linux.
 * INI file must be in the same folder where respective dynamic library is
 */
package CRYPTOCard.Test;

import CRYPTOCard.API.*;

/**
 *
 * @author kmushtaq
 */
public class Main
{

    static int AUTH_FAILURE = 0;
    static int AUTH_SUCCESS = 1;
    static int CHALLENGE = 2;
    static int SERVER_PIN_PROVIDED = 3;
    static int USER_PIN_CHANGE = 4;
    static int OUTER_WINDOW_AUTH = 5;
    static int CHANGE_STATIC_PASSWORD = 6;
    static int STATIC_CHANGE_FAILED = 7;
    static int PIN_CHANGE_FAILED = 8;

    public static void main(String[] args)
    {
        try
        {
            /*
             * If the library is not in the PATH envirnment variable, please correct these paths.
             * On windows, the envirnment variable is set by the API Manager.
             */
            String LinuxLibPath = "/usr/local/cryptocard/javaapi/bin/libJCryptoWrapper.so";
            String WindowsLibPath = "C:/Program Files/CRYPTOCard/BlackShield ID/JavaAPI/bin/x86/JCryptoWrapperWin.dll";
            String osLoadLib;

            String osname = System.getProperty("os.name");
            if (osname.toLowerCase().contains("windows"))
            {
                osLoadLib = WindowsLibPath;
            }
            else
            {
                osLoadLib = LinuxLibPath;
            }

            CRYPTOCardAPI cryptocardApi = CRYPTOCardAPI.getInstance();

            System.out.println("Instance Creation OK");

            //Load libraries from Path set by API Manager
            //cryptocardApi.LoadJNILibrary();

            // Use this line if the path is not set by API Manager
            // This must be only used if the line above fails.
            cryptocardApi.LoadJNILibrary(osLoadLib);

            //no error thrown means initialization is OK
            System.out.println("Loading and Initialization OK");

            /*
            jstring UserName;
            jstring Organization;
            jstring OTP;
            jstring Challenge;
            jstring State;
            jstring ChallengeData;
            jstring ChallengeMessage;
            jstring ReturndResult;
            jstring BothServersDown;
            jstring ErrorMessage;
            jstring IP;
             */


            String[] arrData = new String[11];

            arrData[0] = "Administrator";               //username input parameter
            arrData[1] = "";                            //organization input parameter
            arrData[2] = "";                            //Pin + OTP input parameter
            arrData[3] = "";                            //Challenge ouput parameter
            arrData[4] = "";                            //State in / ouput parameter
            arrData[5] = "";                            //ChallengeData ouput parameter
            arrData[6] = "";                            //ChallengeMessage ouput parameter
            arrData[7] = "";                            //ReturndResult ouput parameter - Normal BSID return results 0 to 8
            arrData[8] = "";                            //BothServersDown ouput parameter - 1 or 0 (1 if down)
            arrData[9] = "";                            //ErrorMessage ouput parameter - Error Message for Log or client
            arrData[10] = "127.0.0.1";                  //Client IP Address input parameter

            cryptocardApi.Authenticate(arrData);

            if (Integer.parseInt(arrData[7]) == AUTH_SUCCESS)
            {
                System.out.println(String.format("Authentication Test OK"));
            }
            else if (Integer.parseInt(arrData[7]) == AUTH_FAILURE)
            {
                System.out.println(String.format("Authentication FAILED"));
            }
            else if (Integer.parseInt(arrData[7]) == CHALLENGE)
            {
                System.out.println("Authentication Challenge");
                System.out.println("Returned Challenge:");
                System.out.println(arrData[3]);

                System.out.println("Returned State:");
                System.out.println(arrData[4]);

                //challenge thrown, now next call must accompany returned state from lastr call
                arrData[0] = "Administrator";               //username input parameter
                arrData[1] = "";                            //organization input parameter
                arrData[2] = "SamplePassword";                      //new PIN, New Static Password or Next Pin+OTP - input parameter
                arrData[3] = "";                            //Challenge ouput parameter
                //arrData[4] = "Returned State";              //State in / ouput parameter
                arrData[5] = "";                            //ChallengeData ouput parameter
                arrData[6] = "";                            //ChallengeMessage ouput parameter
                arrData[7] = "";                            //ReturndResult ouput parameter - Normal BSID return results 0 to 8
                arrData[8] = "";                            //BothServersDown ouput parameter - 1 or 0 (1 if down)
                arrData[9] = "";                            //ErrorMessage ouput parameter - Error Message for Log or client
                arrData[10] = "127.0.0.1";                  //Client IP Address input parameter

                //call again to get authentication request response
                cryptocardApi.Authenticate(arrData);

                if (Integer.parseInt(arrData[7]) == AUTH_SUCCESS)
                {
                    System.out.println(String.format("Challenge / Response Authentication Test OK"));
                }
                else if (Integer.parseInt(arrData[7]) == AUTH_FAILURE)
                {
                    System.out.println(String.format("Challenge / Response Authentication FAILED"));
                }

            }
            else
            {
                //Must handle following cases the way challenge response is handled above:
                    /*
                static int USER_PIN_CHANGE = 4;
                static int OUTER_WINDOW_AUTH = 5;
                static int CHANGE_STATIC_PASSWORD = 6;
                static int STATIC_CHANGE_FAILED = 7;
                static int PIN_CHANGE_FAILED = 8;
                 */

                System.out.println("Returned Code:");
                System.out.println(arrData[7]);

                System.out.println("Returned Challenge:");
                System.out.println(arrData[3]);

                System.out.println("Returned State:");
                System.out.println(arrData[4]);
            }













            // Testing Signature Verification
                /*
            arrData (Strings Array) Details:
            These should be passed only to Verify Signatures
            SerialNumber        = 0                 In Value
            Hash                = 1                 In Value
            Signature           = 2                 In Value
            ReturndResult       = 3                 Return Value -> Result (1 Success 0 Failure)
             */

            arrData = new String[4];
            arrData[0] = "121212121212";               //SerialNumber input parameter
            arrData[1] = "xsxsxsxsxsxsxsxsx";          //Hash input parameter
            arrData[2] = "dsfcdsfdfsdfsf";             //Signature input parameter
            arrData[3] = "";                           //ReturndResult ouput parameter

            //lets verify signatures
            cryptocardApi.VerifySignature(arrData);

            if (Integer.parseInt(arrData[3]) == AUTH_SUCCESS)
            {
                System.out.println(String.format("Signature Verification OK"));
            }
            else if (Integer.parseInt(arrData[3]) == AUTH_FAILURE)
            {
                System.out.println(String.format("Signature Verification FAILED"));
            }
        }
        catch (UnsatisfiedLinkError ex1)
        {
            System.out.println(ex1.getMessage());
        }
        catch (Exception ex)
        {
            System.out.println(ex.getMessage());
        }
    }
}
